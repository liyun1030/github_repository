

import java.util.ArrayList;
import java.util.Collections;


public class distanceCollection 
{
	private ArrayList<distance> mDistanceList;
	
	public distanceCollection()
	{
		mDistanceList = new ArrayList<distance>();
	}
	
	public void add(distance instance)
	{
		mDistanceList.add(instance);
	}
	
	public PointOnChart getNearestPoint()
	{
		Collections.sort(mDistanceList);
		return mDistanceList.get(0).getPoint();
	}
	
	public float getNearestDistance()
	{
		return mDistanceList.get(0).getDistance();
	}
}
