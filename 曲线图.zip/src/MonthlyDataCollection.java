

import java.util.ArrayList;

public class MonthlyDataCollection 
{
	ArrayList<MonthlyDataStructure> mMonthlyDataCollection = new ArrayList<MonthlyDataStructure>();
	
	public void add(MonthlyDataStructure item)
	{
		mMonthlyDataCollection.add(item);
	}
	
	public int datasize()
	{
		return mMonthlyDataCollection.size();
	}
	
	public MonthlyDataStructure getCurrentMonthlyData(int i)
	{
		return mMonthlyDataCollection.get(i);
	}
}
