

public class YAixsAttribute 
{
	private float mYUnitLength;
	private float mNumberOfYPositiveUnit;
	private float mDisplayWidth;
	private int mYAxisNameColor;
	private int mYAxisColor;
	private float mYAxisWidth;
	private float mYAxisNameWidth;
	private float mLineChartHeight;
	
	public void initLineChartBodyDefaultAttribute()
	{
		mYAxisColor = LineChartConstant.YAXIS_DEFAULT_COLOR;
		mYAxisNameColor = LineChartConstant.YAXIS_NAME_DEFAULT_COLOR;
		mYAxisWidth = LineChartConstant.YAXIS_DEFAULT_WIDTH;
		mYAxisNameWidth = LineChartConstant.YAXIS_NAME_DEFAULT_WIDTH;
	}

	public float getLineChartHeight()
	{
		return mLineChartHeight;
	}
	
	public void setLineChartHeight(float height)
	{
		mLineChartHeight = height;
	}
	
	public int getYAxisNameColor()
	{
		return mYAxisNameColor;
	}
	
	public float getYAxisWidth()
	{
		return mYAxisWidth;
	}
	
	public float getYAxisNameWidth()
	{
		return mYAxisNameWidth;
	}
	
	public float getDisplayWidth()
	{
		return mDisplayWidth;
	}
	
	public void setDisplayWidth(float width)
	{
		mDisplayWidth = width;
	}
	
	public void setYUnitLength(float y)
	{
		mYUnitLength = y;
	}
	
	public float getYUnitLength()
	{
		return mYUnitLength;
	}
	
	public void setNumberOfYPositiveUnit(float y)
	{
		mNumberOfYPositiveUnit = y;
	}
	
	public float getNumberOfYPositiveUnit()
	{
		return mNumberOfYPositiveUnit;
	}
	
	public int getYAxisColor()
	{
		return mYAxisColor;
	}
	
	public int getMaxYValue()
	{
		return LineChartDataUtil.getMaxYValue(mNumberOfYPositiveUnit);
	}
}
