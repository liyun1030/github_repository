

import java.util.ArrayList;


public class PathOnChart 
{
	public PathAttributes mAttributes;
	public ArrayList<PointOnChart> mPoints;

	public PathOnChart(ArrayList<PointOnChart> points,
			PathAttributes pathAttributes) 
	{
		this.mAttributes = pathAttributes;
		this.mPoints = points;
		int size = this.mPoints.size();
		String color = this.mAttributes.getPointColor();
		for( int i = 0; i < size; i++)
		{
			PointOnChart point = this.mPoints.get(i);
			point.setColor(color);
		}
	}
	
	public String getPathColor()
	{
		return mAttributes.getPathColor();
	}
	
	public String getPointColor()
	{
		return mAttributes.getPointColor();
	}
	
	public ArrayList<PointOnChart> getPoints()
	{
		return mPoints;
	}
	
	public float getStrokeWidthOfPath()
	{
		return mAttributes.getStrokeWidthOfPath();
	}
	
	public float getRadiusOfPoints()
	{
		return mAttributes.getRadiusOfPoints();
	}
	
	public int getFirstNoneDummyPointIndex()
	{
		int size = mPoints.size();
		for( int i = 0; i < size; i++)
		{
			if( !mPoints.get(i).isDummyPoint())
				return i;
		}
		return -1;
	}
	
	public int getFirstVisiblePointX()
	{
		int pointNumber = mPoints.size();
		for( int j = 0; j < pointNumber; j ++)
		{
			if( !mPoints.get(j).isDummyPoint())
				return (int)mPoints.get(j).getConvertedX();
		}
		return -1;
	}
}
