

import android.graphics.Color;

public class LineChartConstant 
{
	static final public float TOP_OFFSET_PERCENT = 0.01f;
	static final public float BOTTOM_OFFSET_PERCENT = 0.25f;
	static final public float LEFT_OFFSET_PERCENT = 0.0f;
	static final public float RIGHT_OFFSET_PERCENT = 0.1f;
	static final public float POINT_RADIUS = 10f;
	
	static final public int XAXIS_DEFAULT_COLOR = Color.WHITE;
	static final public int YAXIS_DEFAULT_COLOR = Color.WHITE;
	static final public int XAXIS_NAME_DEFAULT_COLOR = Color.WHITE;
	static final public int YAXIS_NAME_DEFAULT_COLOR = Color.WHITE;
	static final public int XGRID_DEFAULT_COLOR = Color.GRAY;
	static final public int YGRID_DEFAULT_COLOR = Color.WHITE;
	
	static final public float XAXIS_DEFAULT_WIDTH = 1f;
	static final public float YAXIS_DEFAULT_WIDTH = 1f;
	static final public float XGRID_DEFAULT_WIDTH = 1f;
	static final public float YGRID_DEFAULT_WIDTH = 1f;
	//static final public float XAXIS_NAME_DEFAULT_WIDTH = 0.1f;
	static final public float YAXIS_NAME_DEFAULT_WIDTH = 1f;
	static final public float DEFAULT_PATH_WIDTH = 2f;
	
	static final public float MONTH_MARGIN_ABOVE_XAXIS = 40;
	static final public float YEAR_MARGIN_ABOVE_XAXIS = 20;
	static final public float CHART_WIDTH_PERCENT = 0.95f;
	static final public float CHART_HEIGHT_PERCENT = 0.8f;
	static final public float CLICKED_SCALE_RATE = 1.3f;
	static final public float YEARLY_XAXIS_NAME_OFFSET = 5f;
	static final public float QUATERLY_XAXIS_NAME_OFFSET = 5f;
	static final public float THRESHOLD_X_WIDTH = 100f;
	
	static final public int DEFAULT_UNIT_NUMBER = 15;
	static final public int MAX_UNIT_NUMBER = 40;
	static final public int MIN_UNIT_NUMBER = 3;
	static final public int THRESHOLD_UNIT_NUMBER = 5;
	static final public int DEFAULT_LINE_TEXT_SIZE = 15;
	static final public int DEFAULT_TOOLTIP_TEXT_SIZE = 15;
	static final public int PLACE_HOLDER_MARGIN = 50;
	
	static final public int START_YEAR = 2000;
	static final public int END_YEAR = 2013;
	static final public int DEFAULT_XGRID_LINE_NUMBER = 10;
	static final public int YAXIS_VALUE_X_COORDINATE = 40;
	
	static final public String DEFAULT_POINT_COLOR = "#FF00FF";
	static final public String DEFAULT_PATH_COLOR = "#1C86EE";
	
	static final public int MONTHLY_MODE = 1;
	static final public int QUATERLY_MODE = 2;
	static final public int YEARLY_MODE = 3;
	
	static final public float TRIANGLE_LENGTH = 15f;
	static final public float HORIZONTAL_WIDTH = 65f;
	static final public float TOOL_TIP_EDGE_MARGIN = 2f;
	static final public float TOOL_TIP_END_LENGTH = 30f;
	static final public float TRIANGLE_CAPTION_Y_OFFSET = 32f;
	static final public float TRIANGLE_DATA_Y_OFFSET = 12f;
	static final public float TRIANGLE_RECTANGLE_MARGIN = 5f;
	static final public float INVALID_Y_COORDINATE = -1f;
	
	static final public int YAXIS_NAME_X_OFFSET = 35;
	static final public int YAXIS_NAME_Y_OFFSET = 20;
	static final public int YAXIS_HANDLE_WIDTH = 70;
	
	static final public String[] MONTH_HEADER = {"Jan", "Feb", "Mar", "Apr","May", "Jun", "Jul", "Aug", "Sep", 
			"Oct" , "Nov", "Dec"};
	static final public String[] MONTH_HEADER_TOOLTIP = {"January", "Februry", "Mar", "April","May", "June", "July", 
		"Auguest", "September", "October" , "November", "December"};
	
}
