

import java.util.ArrayList;


public class LineChartPathCollection 
{
	private ArrayList<PathOnChart> mPathCollection;
	
	public ArrayList<PathOnChart> getPathCollection()
	{
		return mPathCollection;
	}
	
	public void release()
	{
		mPathCollection.clear();
	}
	
	public LineChartPathCollection()
	{
		mPathCollection = new ArrayList<PathOnChart>();
	}
	
	public void addPath(PathOnChart path)
	{
		mPathCollection.add(path);
	}
	
	public int pathNumber()
	{
		return mPathCollection.size();
	}
	
	public PathOnChart getCurrentPath(int i)
	{
		return mPathCollection.get(i);
	}
	
	public void removePath(PathOnChart path)
	{
		mPathCollection.remove(path);
	}
	
	public PathOnChart getLongestPath()
	{
		int size = mPathCollection.size();
		int max = 0;
		PathOnChart hitPath = null;
		for( int i = 0; i < size; i++)
		{
			for( int j = i; j < size; j++)
			{
				ArrayList<PointOnChart> currentPoints = mPathCollection.get(j).getPoints();
				if( currentPoints.size() >= max )
				{
					max = currentPoints.size();
					hitPath = mPathCollection.get(j);
				}
			}
		}
		return hitPath;
	}
	
	public int getFirstVisibleLocation()
	{
		int size = mPathCollection.size();
		int min = Integer.MAX_VALUE;
		int x = 0;
		for( int i = 0; i < size; i++)
		{
			x = mPathCollection.get(i).getFirstVisiblePointX();
			if( x < min)
				min = x;
		}
		return min;
	}
}
