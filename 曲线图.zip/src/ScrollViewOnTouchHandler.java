

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.HorizontalScrollView;

public class ScrollViewOnTouchHandler implements OnTouchListener {

	private int mCount;
	private HorizontalScrollView mHostView;
	
	public ScrollViewOnTouchHandler(HorizontalScrollView view)
	{
		mHostView = view;
	}
	
	@Override
	public boolean onTouch(View v, MotionEvent event) 
	{
		System.out.println("Index: " + mCount++ + "X: " + event.getX() + " Y: " + event.getY());
		mHostView.scrollTo(100, 0);
		return false;
	}
	

}
