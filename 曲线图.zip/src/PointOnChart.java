


public class PointOnChart implements Comparable<PointOnChart> 
{
	private float mConvertedX;
	private float mConvertedY;
	private float mOriginalX;
	private float mOriginalY;
	private String mColor;
	private boolean mIsDummyPoint;
	private MonthlyDataStructure mDataModel;
	
	public boolean isPointOnPath(LineChartPathCollection pathList)
	{
		int pathNumber = pathList.pathNumber();
		for( int i = 0 ; i < pathNumber; i++)
		{
			if(pathList.getCurrentPath(i).getPoints().contains(this))
				return true;
		}
		return false;
	}
	
	public void setCurrency(String currency)
	{
		mDataModel.setCurrency(currency);
	}
	
	public String getCurrency()
	{
		return mDataModel.getCurrency();
	}
	
	public boolean isDummyPoint()
	{
		return mIsDummyPoint;
	}
	
	public void setIndex(int i)
	{
		mOriginalX = i;
	}
	
	public void setDummyMode()
	{
		mIsDummyPoint = true;
	}
	
	public void setQuaterName(String QuaterName)
	{
		mDataModel.setQuaterName(QuaterName);
	}
	
	public String getQuaterName()
	{
		return mDataModel.getQuaterName();
	}
	
	public void setColor(String color)
	{
		mColor = color;
	}
	
	public String getPointColor()
	{
		return mColor;
	}
	
	public float getOriginalX()
	{
		return mOriginalX;
	}
	
	public float getOriginalY()
	{
		return mOriginalY;
	}
	
	public PointOnChart(float x, float y) 
	{
		mDataModel = new MonthlyDataStructure();
		this.mOriginalX = x;
		this.mOriginalY = y;
	}
	
	public void setConvertedX(float x)
	{
		mConvertedX = x;
	}
	
	public void setConvertedY(float y)
	{
		mConvertedY = y;
	}
	
	public float getConvertedX()
	{
		return mConvertedX;
	}
	
	public float getConvertedY()
	{
		return mConvertedY;
	}
	
	public void setPointRelatedData(int month, int year, float data, String currency)
	{
		mDataModel.setMonth(month);
		mDataModel.setYear(year);
		mDataModel.setData(data);
		mDataModel.setCurrency(currency);
	}
	
	public int getMonth()
	{
		return mDataModel.getMonth();
	}
	
	public int getYear()
	{
		return mDataModel.getYear();
	}
	
	public float getData()
	{
		return mDataModel.getData();
	}
	
	public void setYear(int year)
	{
		mDataModel.setYear(year);
	}
	
	public void setData(float data)
	{
		mDataModel.setData(data);
	}
	
	@Override

	public int hashCode()
	{
		return mDataModel.getQuaterName().hashCode() + mColor.hashCode();
	}

	@Override
	public boolean equals(Object obj)
	{
		PointOnChart other = (PointOnChart) obj;
		if (mDataModel.getData() == other.getData() && mColor.equals(other.getPointColor()) 
				&& mOriginalX == other.getOriginalX() && mOriginalY == other.getOriginalY())
			return true;
		return false;
	}

	@Override
	public int compareTo(PointOnChart arg0) 
	{
		return (int)( this.getYear() - arg0.getYear() );
	}
}
