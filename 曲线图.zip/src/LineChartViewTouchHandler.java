


import android.util.FloatMath;
import android.view.MotionEvent;
import android.view.View;

public class LineChartViewTouchHandler 
{	
	private int mCounter;
	private final float mNearestDectableDistance = 200;
	private LineChartView mLineChartView;
	private int mCurrentMode;
	private float mOldValue;
	private final int MODE_NONE = 1;
	private final int MODE_DRAG = 2;
	private final int MODE_ZOOM = 3;
	
	private void log(String log)
	{
		System.out.println("******** Event" + mCounter++ + ":" + log);
	}
	
	private boolean emptyClickDetected(float nearestDistance)
	{
		return nearestDistance > mNearestDectableDistance?true:false;
	}
	
	private void displayEventDetail(MotionEvent event, PointOnChart point)
	{
		log("Current clicked X: " + event.getX());
		log("Current clicked Y: " + event.getY());
		log("Current Point X: " + point.getConvertedX());
		log("Current Point Y: " + point.getConvertedY());
	}
	
	public boolean HandleTouch(View v, MotionEvent event)
	{		
		mLineChartView = (LineChartView)v; 
		switch (event.getAction() & MotionEvent.ACTION_MASK) 
		{ 
			case MotionEvent.ACTION_DOWN:
				System.out.println("in ACTION_DOWN!");
				mCounter = 0;
				mCurrentMode = MODE_DRAG;
				distanceCollection distanceList = new distanceCollection(); 
				LineChartDataUtil.fillDistanceList(distanceList, event, mLineChartView);
				PointOnChart point = distanceList.getNearestPoint();
				if( emptyClickDetected(distanceList.getNearestDistance()))
					return true;
				System.out.println("CLICKED POINT INDEX: " + LineChartDataUtil.getPointIndexinCurrentPath(point, mLineChartView));
				displayEventDetail(event,point);
				mLineChartView.displayToolTip(point);
				break; 

			case MotionEvent.ACTION_UP:
				mCounter = 0;
				break; 
				
			case MotionEvent.ACTION_POINTER_UP:
				log("Event: ACTION_POINTER_UP, now mode = NONE" );
				mCurrentMode = MODE_NONE;
				mOldValue = 0;
				mCounter = 0;
				break; 
				
			case MotionEvent.ACTION_POINTER_DOWN: 
				mOldValue = spacing(event); 
				if(mOldValue > 10f)
				{ 
					log("Now Mode = ZOOM");
					mCurrentMode = MODE_ZOOM;
				} 
				break; 

			case MotionEvent.ACTION_MOVE: 
				System.out.println("in ACTION_MOVE!");
				if(mCurrentMode == MODE_ZOOM)
				{ 
					log("In ZOOM Mode");
					float newDist = spacing(event); 
					if(newDist > 10f)
					{
						float rate = newDist - mOldValue;
						mLineChartView.scale(rate);
					} 
				} 
				break; 
		}
		return true;
	}
	
	private float spacing(MotionEvent event) 
	{ 
		float x = event.getX(0) - event.getX(1); 
		float y = event.getY(0) - event.getY(1); 
		return FloatMath.sqrt(x * x + y * y); 
	}

}
