

public class MonthlyDataStructure 
{
	private int mYear;
	private int mMonth;
	private float mData;
	private String mCurrency;
	private String mQuaterName;
	
	public MonthlyDataStructure(int year, int month, float data, String currency)
	{
		mYear = year;
		mMonth = month;
		mData = data;
		mCurrency = currency;
	}
	
	public void setQuaterName(String name)
	{
		mQuaterName = name;
	}
	
	public String getQuaterName()
	{
		return mQuaterName;
	}
	
	public void setCurrency(String currency)
	{
		mCurrency = currency;
	}
	
	public String getCurrency()
	{
		return mCurrency;
	}
	
	public MonthlyDataStructure()
	{
		
	}
	
	public void setData(float data)
	{
		mData = data;
	}
	
	public float getData()
	{
		return mData;
	}
	
	public int getMonth()
	{
		return mMonth;
	}
	
	public void setMonth(int month)
	{
		mMonth = month;
	}
	
	public void setYear(int year)
	{
		mYear = year;
	}
	
	public int getYear()
	{
		return mYear;
	}
}
