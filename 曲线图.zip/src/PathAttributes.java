



public class PathAttributes 
{
	private String mPathColor;
	private String mPointColor;
	private float mStrokeWidthOfPath;
	private float mRadiusOfPoints;

	public PathAttributes()
	{
		setDefaultAttributes();
	}
	
	private void setDefaultAttributes()
	{
		mPathColor = LineChartConstant.DEFAULT_PATH_COLOR;
		mPointColor = LineChartConstant.DEFAULT_POINT_COLOR;
		mStrokeWidthOfPath = LineChartConstant.DEFAULT_PATH_WIDTH;
		mRadiusOfPoints = LineChartConstant.POINT_RADIUS;
	}
	
	public String getPathColor() 
	{
		return mPathColor;
	}

	public void setPathColor(String pathColor) 
	{
		mPathColor = pathColor;
	}

	public String getPointColor() 
	{
		return mPointColor;
	}

	public void setPointColor(String pointColor) 
	{
		mPointColor = pointColor;
	}

	public float getStrokeWidthOfPath() 
	{
		return mStrokeWidthOfPath;
	}

	public void setStrokeWidthOfPath(float strokeWidthOfPath) 
	{
		mStrokeWidthOfPath = strokeWidthOfPath;
	}

	public float getRadiusOfPoints() 
	{
		return mRadiusOfPoints;
	}

	public void setRadiusOfPoints(float radiusOfPoints) 
	{
		this.mRadiusOfPoints = radiusOfPoints;
	}
}
