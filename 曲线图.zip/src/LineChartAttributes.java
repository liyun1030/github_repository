

import android.graphics.Bitmap;


public class LineChartAttributes 
{
	private boolean mGridVisible;
	
	private Bitmap mBackgroundBitMap;
	private float mDisplayHeight;
	private float mDisplayWidth;
	private int mYGridColor;
	private float mYGridWidth;
	private int mXGridColor;
	private float mXGridWidth;
	private int mXAxisColor;
	private float mXAxisWidth;
	private int mXAxisNameColor;
	//private float mXAxisNameWidth;

	public void initLineChartBodyDefaultAttribute()
	{
		mXAxisColor = LineChartConstant.XAXIS_DEFAULT_COLOR;
		mXAxisNameColor = LineChartConstant.XAXIS_NAME_DEFAULT_COLOR;
		mYGridColor = LineChartConstant.YGRID_DEFAULT_COLOR;
		mXGridColor = LineChartConstant.XGRID_DEFAULT_COLOR;
		
		mXAxisWidth = LineChartConstant.XAXIS_DEFAULT_WIDTH;
		//mXAxisNameWidth = LineChartConstant.XAXIS_NAME_DEFAULT_WIDTH;
		mYGridWidth = LineChartConstant.YGRID_DEFAULT_WIDTH;
		mXGridWidth = LineChartConstant.XGRID_DEFAULT_WIDTH;
	}
	
	public int getXAxisNameColor()
	{
		return mXAxisNameColor;
	}
	
	public float getXAxisWidth()
	{
		return mXAxisWidth;
	}
	
	public int getXAxisColor()
	{
		return mXAxisColor;
	}
	
	public int getYGridColor()
	{
		return mYGridColor;
	}
	
	public int getXGridColor()
	{
		return mXGridColor;
	}
	
	public float getYGridWidth()
	{
		return mYGridWidth;
	}
	
	public float getXGridWidth()
	{
		return mXGridWidth;
	}
	
	public boolean isGridVisible() 
	{
		return mGridVisible;
	}

	public void setGridVisible(boolean gridVisible) 
	{
		this.mGridVisible = gridVisible;
	}

	public Bitmap getBackgroundBitmap() 
	{
		return mBackgroundBitMap;
	}

	public void setBackgroundBitmap(Bitmap background) 
	{
		this.mBackgroundBitMap = background;
	}
	
	public void setDisplayHeight(float height)
	{
		mDisplayHeight = height;
	}
	
	public void setDisplayWidth(float width)
	{
		mDisplayWidth = width;
	}
	
	public float getDisplayWidth()
	{
		return mDisplayWidth;
	}
	
	public float getDisplayHeight()
	{
		return mDisplayHeight;
	}
}
