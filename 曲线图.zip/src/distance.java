



public class distance  implements Comparable<distance> 
{
	private float mDistance;
	private PointOnChart mPoint;
	private PathOnChart mParentPath;
	
	public PathOnChart getParentPathInstance()
	{
		return mParentPath;
	}
	
	public distance(float eventX, float eventY, PointOnChart _point, PathOnChart path)
	{
		mPoint = _point;
		mDistance = ( eventX - mPoint.getConvertedX()) * ( eventX - mPoint.getConvertedX() ) + 
				( eventY - mPoint.getConvertedY()) * ( eventY - mPoint.getConvertedY());
		mParentPath = path;
	}
	
	public float getDistance()
	{
		return mDistance;
	}

	public PointOnChart getPoint()
	{
		return mPoint;
	}
	
	@Override
	public int compareTo(distance arg0) 
	{
		
		return (int)( this.mDistance - arg0.getDistance() );
	}
}
