﻿


import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

public class TooltipHandler 
{
	private Paint mToolTipPaint;
	private Paint mTrianglePaint;
	private Paint mEdgePaint;
	private PointOnChart mPoint;
	private LineChartView mLineChartView;
	private float mStartX;
	private float mStartY;
	private float mTriangleLength = LineChartConstant.TRIANGLE_LENGTH;
	private float mHorizontalWidth = LineChartConstant.HORIZONTAL_WIDTH;
	private float mMargin = LineChartConstant.TOOL_TIP_EDGE_MARGIN;
	private float mScaledWidth = LineChartConstant.POINT_RADIUS * LineChartConstant.CLICKED_SCALE_RATE;
	
	public TooltipHandler(LineChartView view )
	{
		mLineChartView = view;
		mToolTipPaint = view.getTooltipPaint();
		mTrianglePaint  = view.getTooltipPaint();
		mEdgePaint = view.getEdgePaint();
	}
	
	private String getFormattedAmount(PointOnChart point)
	{
		String currency = point.getCurrency();
		if( currency == null)
			return null;
		if( currency.equals("USD") )
			return "US$" + point.getData();
		else if ( currency.equals("EUR"))
			return "EU€" + point.getData();
		else return String.valueOf(point.getData());
	}
	
	public void drawToolTip(PointOnChart point, Canvas canvas, float x, float y, float r)
	{
		if( point.isDummyPoint())
			return;
		int year = point.getYear();
		String text = null;
		
		switch (mLineChartView.getCurrentMode()) 
		{
			case LineChartConstant.MONTHLY_MODE:
				String month = mLineChartView.getXAxisNameCollection().getMonthTooltipNamebyIndex(point.getMonth()-1);
				text = month + " " + year;
				break;
			case LineChartConstant.QUATERLY_MODE:
				String quarter = point.getQuaterName();
				text = quarter + " " + year;
				break;
			case LineChartConstant.YEARLY_MODE:
				text = " " + year;
				break;
			default:
				break;
		}
		mPoint = point;
		mStartX = mPoint.getConvertedX();
		mStartY = mPoint.getConvertedY() - mScaledWidth	- LineChartConstant.TRIANGLE_RECTANGLE_MARGIN;
		if( Math.abs(mStartY - mLineChartView.getYTL()) < LineChartConstant.TRIANGLE_CAPTION_Y_OFFSET )
			drawOppositeTriangle(canvas,text,getFormattedAmount(point));
		else 
			drawTriangle(canvas,text,getFormattedAmount(point));
	}
	
	private void drawTriangle(Canvas canvas, String text, String amount)
	{
		mTrianglePaint.setColor(Color.parseColor(mPoint.getPointColor()));
		Path path = new Path();     
		path.setFillType(Path.FillType.EVEN_ODD);     
		path.moveTo(mStartX,mStartY); // A    
		float xb = mStartX;
		float yb = mStartY - mTriangleLength;
		path.lineTo(xb, yb); // B
		float xc = mStartX + mTriangleLength;
		float yc = yb;
		path.lineTo(xc, yc); // C
		path.lineTo(mStartX, mStartY);     
		path.close();      
		canvas.drawPath(path, mTrianglePaint); 
		
		float xd = xc + mHorizontalWidth;
		float yd = yc;
		canvas.drawLine(xc, yc, xd, yd, mTrianglePaint); //CD
		
		mTrianglePaint.setStrokeWidth(2f);
		float xe = xd + LineChartConstant.TOOL_TIP_END_LENGTH;
		float ye = yd - LineChartConstant.TOOL_TIP_END_LENGTH;
		canvas.drawLine(xd, yd, xe, ye, mTrianglePaint); //E
		
		// B'A'
		canvas.drawLine(xb - mMargin, yb, mStartX - mMargin, mStartY + mMargin, mEdgePaint);
		// A'C'
		canvas.drawLine(mStartX - mMargin, mStartY + mMargin, xc + mMargin, yc, mEdgePaint);
		
		mToolTipPaint.setColor(Color.WHITE);
		canvas.drawText(text, mStartX, yb - LineChartConstant.TRIANGLE_CAPTION_Y_OFFSET, mToolTipPaint);
		
		canvas.drawText(amount, mStartX, yb - LineChartConstant.TRIANGLE_DATA_Y_OFFSET, mToolTipPaint);
	}
	
	private void drawOppositeTriangle(Canvas canvas, String text, String amount)
	{
		mStartY = mPoint.getConvertedY() + mScaledWidth + LineChartConstant.TRIANGLE_RECTANGLE_MARGIN;
		mTrianglePaint.setColor(Color.parseColor(mPoint.getPointColor()));
		Path path = new Path();     
		path.setFillType(Path.FillType.EVEN_ODD);     
		path.moveTo(mStartX,mStartY); // A    
		float xb = mStartX;
		float yb = mStartY + mTriangleLength;
		path.lineTo(xb, yb); // B
		float xc = mStartX + mTriangleLength;
		float yc = yb;
		path.lineTo(xc, yc); // C
		path.lineTo(mStartX, mStartY);     
		path.close();      
		canvas.drawPath(path, mTrianglePaint); 
		
		float xd = xc + mHorizontalWidth;
		float yd = yc;
		canvas.drawLine(xc, yc, xd, yd, mTrianglePaint); //CD
		
		mTrianglePaint.setStrokeWidth(2f);
		float xe = xd + LineChartConstant.TOOL_TIP_END_LENGTH;
		float ye = yd + LineChartConstant.TOOL_TIP_END_LENGTH;
		canvas.drawLine(xd, yd, xe, ye, mTrianglePaint); //E
		
		// B'A'
		canvas.drawLine(xb - mMargin, yb, mStartX - mMargin, mStartY - mMargin, mEdgePaint);
		// A'C'
		canvas.drawLine(mStartX - mMargin, mStartY - mMargin, xc + mMargin, yc, mEdgePaint);
		
		mToolTipPaint.setColor(Color.WHITE);
		canvas.drawText(text, mStartX, yb + LineChartConstant.TRIANGLE_DATA_Y_OFFSET, mToolTipPaint);
		
		canvas.drawText(amount, mStartX, yb + LineChartConstant.TRIANGLE_CAPTION_Y_OFFSET, mToolTipPaint);
	}
}
