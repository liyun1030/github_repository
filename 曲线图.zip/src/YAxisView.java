




import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public class YAxisView extends View 
{
	private YAixsAttribute mYAxisAttribute;
	private Paint mLinePaint;
	private Activity mActivity;
	private Bitmap mBackground;
	
	private void initLinePainter()
	{
		mLinePaint = new Paint();
		mLinePaint.setStrokeJoin(Paint.Join.ROUND);
		mLinePaint.setStrokeCap(Paint.Cap.ROUND);
		mLinePaint.setAntiAlias(true);
		mLinePaint.setDither(true);
		mLinePaint.setTextSize(15);
		mLinePaint.setColor(Color.WHITE);
	}
	
	public YAxisView(Activity activity, YAixsAttribute attr) 
	{
		super(activity);
		initLinePainter();
		mYAxisAttribute = attr;
		mActivity = activity;
	}
	
	public void refresh(float newMaxYUnit, float newYUnitLength)
	{
		mYAxisAttribute.setNumberOfYPositiveUnit(newMaxYUnit);
		mYAxisAttribute.setYUnitLength(newYUnitLength);
		this.invalidate();
	}
	
	@Override
	protected void onDraw(Canvas canvas) 
	{
		super.onDraw(canvas);
		canvas.drawBitmap(mBackground, 0, 0, mLinePaint);
		drawYAxisName(canvas);
		drawYAxisValue(canvas);
	}
	
	private void drawYAxisValue(Canvas canvas)
	{
		int y = mYAxisAttribute.getMaxYValue();
		int count = LineChartConstant.DEFAULT_XGRID_LINE_NUMBER;
		float height = mYAxisAttribute.getLineChartHeight();
		for( int i = 0 ; i < count + 1; i++)
		{
			canvas.drawText(getYAxisText( (i * y / count)), LineChartConstant.YAXIS_VALUE_X_COORDINATE, 
					( count + 1 - i ) * height / count, mLinePaint);
		}
	}
	
	private void drawYAxisName(Canvas canvas)
	{
		Path textPath = new Path();
		//textPath.moveTo(LineChartConstant.YAXIS_NAME_X_OFFSET,LineChartConstant.YAXIS_NAME_Y_OFFSET);
		//for(int i = 0; i < LineChartConstant.YAXIS_NAME_Y_OFFSET; i++)
		//	textPath.lineTo(LineChartConstant.YAXIS_NAME_X_OFFSET, i * 10);
		textPath.moveTo(LineChartConstant.YAXIS_NAME_X_OFFSET, ( LineChartConstant.YAXIS_NAME_Y_OFFSET - 1 )
				 * 10 );
		for(int i = LineChartConstant.YAXIS_NAME_Y_OFFSET - 1; i >=0; i--)
			textPath.lineTo(LineChartConstant.YAXIS_NAME_X_OFFSET, i * 10);
		canvas.drawTextOnPath("Revenue in EUR", textPath, 20, 0, mLinePaint);
	}
	
	private String getYAxisText(int i )
	{
		if( i < 1000)
			return String.valueOf(i);
		return "" + i / 1000 + "k";
	}
	
}