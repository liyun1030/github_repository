

import java.util.ArrayList;


public class XAxisNameCollection 
{
	private ArrayList<String> mMonthlyNameCollection;
	private final int mStartYear = LineChartConstant.START_YEAR;
	private final int mEndYear = LineChartConstant.END_YEAR;
	
	private String getMonth(int index)
	{
		if ( index < 10 )
			return new String("0" + index);
		else
			return String.valueOf(index);
	}
	
	public XAxisNameCollection()
	{
		fillMonthlyList();
	}
	
	private void fillMonthlyList()
	{
		int start = mStartYear;
		mMonthlyNameCollection = new ArrayList<String>();
		String item = null;
		while( start <= mEndYear)
		{
			for( int i = 0; i < 12;i++)
			{
				item = start + "." + getMonth( i+1);
				mMonthlyNameCollection.add(item);
			}
			start++;
		}
	}
	
	public int monthlysize()
	{
		return mMonthlyNameCollection.size();
	}
	
	public String getMonthSemanticNamebyIndex(int i)
	{
		String monthNum = mMonthlyNameCollection.get(i).split("\\.")[1];
		int index = Integer.valueOf(monthNum);
		return LineChartConstant.MONTH_HEADER[index-1];
	}
	
	public String getMonthTooltipNamebyIndex(int i)
	{
		String monthNum = mMonthlyNameCollection.get(i).split("\\.")[1];
		int index = Integer.valueOf(monthNum);
		return LineChartConstant.MONTH_HEADER_TOOLTIP[index-1];
	}
	
	public String getYearbyIndex(int i)
	{
		return mMonthlyNameCollection.get(i).split("\\.")[0];
	}
}
