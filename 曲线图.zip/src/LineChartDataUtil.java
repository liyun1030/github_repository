

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import android.view.MotionEvent;

public class LineChartDataUtil 
{
	static public void formatPoints(ArrayList<PointOnChart> points)
	{
		ArrayList<PointOnChart> inPoints = points;
		for( int i = LineChartConstant.START_YEAR; i <= LineChartConstant.END_YEAR; i++)
		{
			if( isDataExistForYear(i, points))
				continue;
			for( int j = 1; j < 13; j++)
				inPoints.add(getDummyDataforYear(j,i));
		}
		Collections.sort(inPoints);
		int size = inPoints.size();
		for( int k = 0; k < size; k++)
		{
			inPoints.get(k).setIndex(k);
		}
	}
	
	static private PointOnChart getDummyDataforYear(int month, int year)
	{
		PointOnChart point = new PointOnChart(month - 1, 0);
		point.setPointRelatedData(month,year, 0f, null);
		point.setDummyMode();
		return point;
	}
	
	static private boolean isDataExistForYear(int year, ArrayList<PointOnChart> point)
	{
		int size = point.size();
		for( int i = 0; i < size; i++)
			if( point.get(i).getYear() == year)
				return true;
		return false;
	}
	
	static public void fillPointsCollectionFromBackendData(ArrayList<PointOnChart> points, 
			MonthlyDataCollection monthlydata, HashMap<String,MonthlyDataCollection> sampleData )
	{
		int index = 0;
		ArrayList<PointOnChart> inPoints = points;
		MonthlyDataCollection inNames = monthlydata;
		MonthlyDataCollection firstProductData = sampleData.get("00001");
		for (int i = 0; i < firstProductData.datasize(); i++) 
		{
			MonthlyDataStructure item = firstProductData.getCurrentMonthlyData(i);
			int year = item.getYear();
			if( year < LineChartConstant.START_YEAR || year > LineChartConstant.END_YEAR)
				continue;
			float data = item.getData();
			int month = item.getMonth();
			String currency = item.getCurrency();
			
			PointOnChart point = new PointOnChart(index++, data);
			point.setPointRelatedData(month, year, data, currency);
			inPoints.add(point);
			MonthlyDataStructure monthlyData = new MonthlyDataStructure(year, month, data, currency);
			inNames.add(monthlyData);
		}
		formatPoints(inPoints);
	}
	
	static public void fillPointsCollectionFromBackendData(ArrayList<PointOnChart> points, 
			MonthlyDataCollection monthlydata)
	{
		int index = 0;
		ArrayList<PointOnChart> inPoints = points;
		MonthlyDataCollection inNames = monthlydata;
		for (int i = 0; i < inNames.datasize(); i++) 
		{
			MonthlyDataStructure item = inNames.getCurrentMonthlyData(i);
			int year = item.getYear();
			if( year < LineChartConstant.START_YEAR || year > LineChartConstant.END_YEAR)
				continue;
			float data = item.getData();
			int month = item.getMonth();
			String currency = item.getCurrency();
			
			PointOnChart point = new PointOnChart(index++, data);
			point.setPointRelatedData(month, year, data, currency);
			inPoints.add(point);
//			MonthlyDataStructure monthlyData = new MonthlyDataStructure(year, month, data, currency);
//			inNames.add(monthlyData);
		}
		formatPoints(inPoints);
	}
	
	static private void calculateQuaterlyPath(LineChartView view)
	{
		LineChartPathCollection monthlyPath = view.getMonthlyPath();
		LineChartPathCollection quaterlyPath = getQuaterlyPath(monthlyPath);
		view.setQuaterlyPath(quaterlyPath);
	}
	
	static private void calculateYearlyPath(LineChartView view)
	{
		LineChartPathCollection monthlyPath = view.getMonthlyPath();
		LineChartPathCollection yearlyPath = getYearlyPath(monthlyPath);
		view.setYearlyPath(yearlyPath);
	}
	
	static public void calculateOtherPaths(LineChartView view)
	{
		calculateQuaterlyPath(view);
		calculateYearlyPath(view);
	}
	
	static private int getQuaterNumbyIndex(int index)
	{
		int result = index % 4;
		return result == 0?4:result;
	}
	
	static private LineChartPathCollection getQuaterlyPath(LineChartPathCollection monthlyPath)
	{
		// WE MUST MAKE SURE monthlyPath IS SORTED AND WELL FORMATTED ( ie, INDEX 0 REPRESENT JANUARY OF ONE 
		// SPECIFIC YEAR ) BEFORE ENTERING THIS METHOD
		int pathSize = monthlyPath.pathNumber();
		LineChartPathCollection quaterlyPath = new LineChartPathCollection();
		for( int i = 0; i < pathSize; i++)
		{
			PathOnChart path = monthlyPath.getCurrentPath(i);
	
			ArrayList<PointOnChart> quaterPointList = new ArrayList<PointOnChart>();
			ArrayList<PointOnChart> points = path.getPoints();
			int PointSize = points.size();
			int quaterlyIndex = 0;
			float quaterlySum = 0;
			for( int j = 0; j < PointSize; j++)
			{
				PointOnChart point = points.get(j);
				quaterlySum += point.getData();
				if( point.getMonth() % 3 == 0)
				{
					PointOnChart pointForQuater = new PointOnChart(quaterlyIndex, quaterlySum);
					pointForQuater.setYear(point.getYear());
					pointForQuater.setData(quaterlySum);
					pointForQuater.setCurrency(point.getCurrency());
					if( point.isDummyPoint())
						pointForQuater.setDummyMode();
					quaterPointList.add(pointForQuater);
					quaterlyIndex++;
					quaterlySum = 0;
					pointForQuater.setQuaterName("Q" + getQuaterNumbyIndex(quaterlyIndex) );
				}
			}
			PathAttributes quaterPathAttributes = new PathAttributes();
			quaterPathAttributes.setPathColor(path.getPathColor());
			quaterPathAttributes.setPointColor(path.getPointColor());
			PathOnChart currentQuaterPath = new PathOnChart(quaterPointList, quaterPathAttributes);
			quaterlyPath.addPath(currentQuaterPath);			
		}
		return quaterlyPath;
	}
	
	static private LineChartPathCollection getYearlyPath(LineChartPathCollection monthlyPath)
	{
		// WE MUST MAKE SURE monthlyPath IS SORTED AND WELL FORMATTED ( ie, INDEX 0 REPRESENT JANUARY OF ONE 
		// SPECIFIC YEAR ) BEFORE ENTERING THIS METHOD
		int pathSize = monthlyPath.pathNumber();
		LineChartPathCollection yearlyPath = new LineChartPathCollection();
		for( int i = 0; i < pathSize; i++)
		{
			PathOnChart path = monthlyPath.getCurrentPath(i);
			ArrayList<PointOnChart> yearlyPointList = new ArrayList<PointOnChart>();
			ArrayList<PointOnChart> points = path.getPoints();
			int PointSize = points.size();
			int yearIndex = 0;
			int currentYear = points.get(0).getYear();
			float yearlySum = 0;
			PointOnChart previousPoint = null;
			for( int j = 0; j < PointSize; j++)
			{
				PointOnChart point = points.get(j);
				if( point.getYear() == currentYear)
				{
					yearlySum += point.getData();
					previousPoint = point;
				}
				else
				{
					PointOnChart pointForYear = new PointOnChart(yearIndex, yearlySum);
					pointForYear.setYear(currentYear);
					pointForYear.setData(yearlySum);
					pointForYear.setCurrency(previousPoint.getCurrency());
					if( previousPoint.isDummyPoint())
						pointForYear.setDummyMode();
					yearlyPointList.add(pointForYear);
					yearIndex++;
					yearlySum = point.getData();
					currentYear = point.getYear();
				}
			}
			// for last one
			PointOnChart LastYear = new PointOnChart(yearIndex, yearlySum);
			LastYear.setYear(currentYear);
			LastYear.setData(yearlySum);
			LastYear.setCurrency(previousPoint.getCurrency());
			if( previousPoint.isDummyPoint())
				LastYear.setDummyMode();
			yearlyPointList.add(LastYear);
			PathAttributes yearPathAttributes = new PathAttributes();
			yearPathAttributes.setPathColor(path.getPathColor());
			yearPathAttributes.setPointColor(path.getPointColor());
			PathOnChart currentYearPath = new PathOnChart(yearlyPointList, yearPathAttributes);
			yearlyPath.addPath(currentYearPath);			
		}
		return yearlyPath;
	}
	
	static public int getPointIndexinCurrentPath(PointOnChart point, LineChartView view)
	{
		ArrayList<PathOnChart> paths = view.getCurrentPath().getPathCollection();
		int pathSize = paths.size();
		for( int i = 0 ; i < pathSize; i++)
		{
			ArrayList<PointOnChart> points = paths.get(i).getPoints();
			int pointSize = points.size();
			for( int j = 0; j < pointSize; j++)
			{
				if( point.equals(points.get(j)))
						return j;
			}
		}
		return -1;
	}
	
	static public void fillDistanceList(distanceCollection distanceList, MotionEvent event, LineChartView view)
	{
		ArrayList<PathOnChart> path = view.getCurrentPath().getPathCollection();
		int pathSize = path.size();
		float x = event.getX();
		float y = event.getY();
		for( int i = 0 ; i < pathSize; i++)
		{
			ArrayList<PointOnChart> points = path.get(i).getPoints();
			int pointSize = points.size();
			for( int j = 0; j < pointSize; j++)
				distanceList.add(new distance(x, y, points.get(j), path.get(i)));
		}
	}
	
	static public int getMaxYValue(float maxY)
	{
		int original = Math.round(maxY);
		int work = original;
		int count = 0;
		int base = 1;
		while ( work != 0)
		{
			work = work / 10;
			count++;
		}
		for( int k = 0; k < count - 1 ; k++)
			base = base * 10;
		for( int i = 0; i < 10 ; i++)
		{
			if( (i * base) >= original)
				return i * base;
		}
		return 0;
	}
}
