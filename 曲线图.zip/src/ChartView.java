

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public abstract class ChartView extends View 
{

	protected Paint mPointPaint;
	protected Paint mLinePaint;
	protected Paint mTooltipPaint;
	protected Paint mTrianglePaint; 
	protected Paint mEdgePaint;

	protected int mDisplay_height;
	protected int mDisplay_width;

	protected float mOffset_top;
	protected float mOffset_bottom;
	protected float mOffset_left;
	protected float mOffset_right;

	protected float mXtl;
	protected float mYtl;
	protected float mXtr;
	protected float mYtr;
	protected float mXbl;
	protected float mYbl;
	protected float mXbr;
	protected float mYbr;
	
	protected float mChart_height;
	protected float mChart_width;

	public ChartView(Activity activity, LineChartAttributes attr) 
	{
		super(activity);

		mDisplay_height = (int)attr.getDisplayHeight();
		mDisplay_width = (int)attr.getDisplayWidth();

		mOffset_top = mDisplay_height * LineChartConstant.TOP_OFFSET_PERCENT;

		mOffset_bottom = mDisplay_height * LineChartConstant.BOTTOM_OFFSET_PERCENT;

		mOffset_left = mDisplay_width * LineChartConstant.LEFT_OFFSET_PERCENT;

		mOffset_right = mDisplay_width * LineChartConstant.RIGHT_OFFSET_PERCENT;

		mChart_width = mDisplay_width - mOffset_right - mOffset_left;
		mChart_height = mDisplay_height - mOffset_top - mOffset_bottom;
		
		mXtl = mOffset_left;
		mYtl = mOffset_top;
		mXtr = mDisplay_width - mOffset_right;
		mYtr = mOffset_top;
		mXbl = mOffset_left;
		mYbl = mDisplay_height - mOffset_bottom;
		mXbr = mDisplay_width - mOffset_right;
		mYbr = mDisplay_height - mOffset_bottom;

		initPointPainter();
		initLinePainter();
		initToolTipPaint();
		initEdgePaint();
		initTrianglePaint();
	}
	
	private void initPointPainter()
	{
		mPointPaint = new Paint();
	}
	
	private void initLinePainter()
	{
		mLinePaint = new Paint();
		mLinePaint.setStrokeJoin(Paint.Join.ROUND);
		mLinePaint.setStrokeCap(Paint.Cap.ROUND);
		mLinePaint.setAntiAlias(true);
		mLinePaint.setDither(true);
		mLinePaint.setTextSize(LineChartConstant.DEFAULT_LINE_TEXT_SIZE);
		mLinePaint.setColor(Color.WHITE);
	}
	
	private void initToolTipPaint()
	{
		mTooltipPaint = new Paint();
		mTooltipPaint.setStrokeJoin(Paint.Join.ROUND);
		mTooltipPaint.setStrokeCap(Paint.Cap.ROUND);
		mTooltipPaint.setAntiAlias(true);
		mTooltipPaint.setDither(true);
		mTooltipPaint.setTextSize(LineChartConstant.DEFAULT_TOOLTIP_TEXT_SIZE);
	}
	
	private void initEdgePaint()
	{
		mEdgePaint = new Paint();
		mEdgePaint.setStrokeWidth(2f);
		mEdgePaint.setColor(Color.WHITE);
		mEdgePaint.setStyle(Paint.Style.STROKE);
	}
	
	private void initTrianglePaint()
	{
		mTrianglePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		mTrianglePaint.setStrokeWidth(1f);
		mTrianglePaint.setStyle(Paint.Style.FILL_AND_STROKE);
		mTrianglePaint.setAntiAlias(true);
		mTrianglePaint.setDither(true);
	}
	
	public Paint getTrianglePaint()
	{
		return mTrianglePaint;
	}
	
	public Paint getEdgePaint()
	{
		return mEdgePaint;
	}
	
	public Paint getTooltipPaint()
	{
		return mTooltipPaint;
	}
	
	public float getChartHeight()
	{
		return mChart_height;
	}
	
	
}
