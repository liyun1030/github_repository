

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import android.app.Activity;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.FloatMath;
import android.view.ViewGroup.LayoutParams;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

public class LineChartView extends ChartView 
{
	private float mNO_of_x_positive_unit;
	private float mNO_of_y_positive_unit;
	private float mNO_of_y_negetive_unit;
	private float mX_unit_length;
	private float mY_unit_length;
	private float mX_translate_factor;
	private float mY_translate_factor;
	private float mMaxCoordinateX = 0;
	private float mOriginalY;
	private float mOriginalX;
	private int mCurrentChartMode;
	private boolean mIsInYearRedrawMode;
	public static ArrayList<String> x_value;
	public static ArrayList<PointOnChart> points;
	public static ArrayList<ArrayList<ProductRevenue>> productRevenues;
	private LineChartPathCollection mMonthlyPaths;
	private LineChartPathCollection mQuaterlyPaths;
	private LineChartPathCollection mYearlyPaths;
	private LineChartAttributes mLineChartAttributes;
	private ArrayList<PointOnChart> mPointsTobeRedraw;
	private XAxisNameCollection mXAxisNameCollection;
	private TooltipHandler mTooltipHandler;
	private HashMap<ArrayList<ProductRevenue>, PathOnChart> mRevenuePathMap;

	public LineChartView(Activity activity, LineChartPathCollection paths,
			LineChartAttributes lineChartAttributes, ArrayList<ProductRevenue> initialRevenue) 
	{
		super(activity,lineChartAttributes);
		productRevenues = new ArrayList<ArrayList<ProductRevenue>>();
		mRevenuePathMap = new HashMap<ArrayList<ProductRevenue>, PathOnChart>();
		mRevenuePathMap.put(initialRevenue, paths.getCurrentPath(0));
		productRevenues.add(initialRevenue);
		mCurrentChartMode = LineChartConstant.MONTHLY_MODE;
		mNO_of_x_positive_unit = LineChartConstant.DEFAULT_UNIT_NUMBER;
		mMonthlyPaths = paths;
		configurePath(paths);
		LineChartDataUtil.calculateOtherPaths(this);
		mXAxisNameCollection = new XAxisNameCollection();
		mPointsTobeRedraw = new ArrayList<PointOnChart>();
		mTooltipHandler = new TooltipHandler(this);
		
		mOriginalY = LineChartDataUtil.getMaxYValue(mNO_of_y_positive_unit) * mY_unit_length + mYtl;
		mOriginalX = mXtl;
		this.mLineChartAttributes = lineChartAttributes;
	}
	
	private void startYearRedrawMode()
	{
		mIsInYearRedrawMode = true;
	}
	
	private void endYearRedrawMode()
	{
		mIsInYearRedrawMode = false;
	}
	
	private void scaleYearMode(float Rate)
	{
		startYearRedrawMode();
		float old = mX_unit_length;
		System.out.println("YEAR MODE Rate: " + Rate + " old X Unit length: " + mX_unit_length);
		mX_unit_length = mX_unit_length + Rate;
		System.out.println("YEAR MODE Rate: " + Rate + " new X Unit length: " + mX_unit_length);
		
		scaleInternal(old);
		endYearRedrawMode();
	}
	
	private void scaleInternal(float old)
	{
		int number = Math.round(mChart_width / mX_unit_length);
		if( number > LineChartConstant.MAX_UNIT_NUMBER || number < LineChartConstant.MIN_UNIT_NUMBER)
		{
			mX_unit_length = old;
			return;
		}
		System.out.println("Number of X: " + number);
		mNO_of_x_positive_unit = number;
		configurePath(mMonthlyPaths);
		mOriginalY = mNO_of_y_positive_unit * mY_unit_length + mYtl;
		mOriginalX = mXtl;
		LineChartDataUtil.calculateOtherPaths(this);
		configureCurrentPath();
		updateRedrawListDuetoPotentialXAxisChange();
		adaptLineChartWidth();
		this.invalidate();
	}
	
	public void scale(float Rate)
	{
		mMaxCoordinateX = 0;
		if( mCurrentChartMode == LineChartConstant.YEARLY_MODE)
		{
			scaleYearMode(Rate);
			return;
		}
		float old = mX_unit_length;
		if( mNO_of_x_positive_unit < LineChartConstant.THRESHOLD_UNIT_NUMBER )
		{
			if( Rate > LineChartConstant.THRESHOLD_X_WIDTH)
				mX_unit_length = mX_unit_length + FloatMath.sqrt(Rate);
			else if ( Rate < 0)
				mX_unit_length = mX_unit_length + 2 * Rate;
		}
		else 
		{
			mX_unit_length = mX_unit_length + Rate;
		}
		scaleInternal(old);
	}
	
	public XAxisNameCollection getXAxisNameCollection()
	{
		return mXAxisNameCollection;
	}
	
	public void setQuaterlyPath(LineChartPathCollection path)
	{
		if( mQuaterlyPaths != null)
			mQuaterlyPaths.release();
		mQuaterlyPaths = path;
	}
	
	public void setYearlyPath(LineChartPathCollection path)
	{
		if( mYearlyPaths != null)
			mYearlyPaths.release();
		mYearlyPaths = path;
	}

	private void switchInternal(int newMode)
	{
		if( newMode == mCurrentChartMode)
		{
			int location = getFirstVisibleLocation();
			System.out.println("First Visible Point: " + location);
			HorizontalScrollView view = (HorizontalScrollView)getParent().getParent();
			view.scrollTo(location, 0);
			return;
		}
		mPointsTobeRedraw.clear();
		mCurrentChartMode = newMode;
		LineChartPathCollection workPath = getCurrentPath();
		configurePath(workPath);
		mOriginalY = LineChartDataUtil.getMaxYValue(mNO_of_y_positive_unit) * mY_unit_length + mYtl;
		mOriginalX = mXtl;
		mMaxCoordinateX = 0;
		adaptLineChartWidth();
		this.invalidate();
	}
	
	private void adaptLineChartWidth()
	{
		int width = getTotalWidth();
		LinearLayout parent = (LinearLayout)getParent();
		parent.removeAllViews();
		parent.addView(this, width, LayoutParams.WRAP_CONTENT);
	}
	
	public int getTotalWidth()
	{
		int width = -1;
		switch (mCurrentChartMode) 
		{
			case LineChartConstant.MONTHLY_MODE:
				width = ( LineChartConstant.END_YEAR - LineChartConstant.START_YEAR + 1)
				 * 12 * (int)mX_unit_length + LineChartConstant.PLACE_HOLDER_MARGIN * 2;
				break;
			case LineChartConstant.QUATERLY_MODE:
				width = ( LineChartConstant.END_YEAR - LineChartConstant.START_YEAR + 1)
				 * 4 * (int)mX_unit_length + LineChartConstant.PLACE_HOLDER_MARGIN;
				break;
			case LineChartConstant.YEARLY_MODE:
				width = ( LineChartConstant.END_YEAR - LineChartConstant.START_YEAR + 1)
				  * (int)mX_unit_length + LineChartConstant.PLACE_HOLDER_MARGIN;
				break;
		}
		return width;
	}
	
	public void switchToQuaterlyMode()
	{
		switchInternal(LineChartConstant.QUATERLY_MODE);
	}
	
	public void switchToMonthlyMode()
	{
		switchInternal(LineChartConstant.MONTHLY_MODE);
	}
	
	public void switchToYearlyMode()
	{
		switchInternal(LineChartConstant.YEARLY_MODE);
	}
	
	private void addNewLineInternal(PathOnChart path)
	{
		mMonthlyPaths.addPath(path);
		configurePath(mMonthlyPaths);
		mOriginalY = mNO_of_y_positive_unit * mY_unit_length + mYtl;
		mOriginalX = mXtl;
		LineChartDataUtil.calculateOtherPaths(this);
		configureCurrentPath();
		updateRedrawListDuetoPotentialYAxisChange();
		this.invalidate();
	}
	
	public void addNewLine(String color, ArrayList<ProductRevenue> revenue)
	{
		if( productRevenues.contains(revenue))
			return;
		PathOnChart path = null;
		ArrayList<PointOnChart> points1 = new ArrayList<PointOnChart>();
		int PointSize = revenue.size();
		int pointIndex = 0;
		PointOnChart point = null;
		for( int i = 0; i < PointSize; i++)
		{
			ProductRevenue item = revenue.get(i);
			point = new PointOnChart(pointIndex++, item.getRevenue());
			point.setPointRelatedData(item.getMonth(), item.getYear(), item.getRevenue(), item.getCurrency());
			points1.add(point);
		}

		PathAttributes pathAttributes1 = new PathAttributes();
		pathAttributes1.setPointColor(color);
		pathAttributes1.setPathColor(color);
		LineChartDataUtil.formatPoints(points1);
		path = new PathOnChart(points1, pathAttributes1);
		mRevenuePathMap.put(revenue, path);
		productRevenues.add(revenue);
		addNewLineInternal(path);
	}
	
	static public LineChartView initLineChartWithClickedRevenue(String color, ArrayList<ProductRevenue> revenue, LineChartView instance, Activity activity)
	{
		if( instance != null)
		{
			if( productRevenues.contains(revenue))
				return instance;
			productRevenues.add(revenue);
			instance.addNewLine(color, revenue);
			return instance;
		}
		else
		{
			ArrayList<PointOnChart> points = new ArrayList<PointOnChart>();
			MonthlyDataCollection monthlyDataCollection = new MonthlyDataCollection();
			monthlyDataCollection = LineChartDataAdapter.convertToLineChartData(revenue);
			LineChartDataUtil.fillPointsCollectionFromBackendData(points, monthlyDataCollection);
			
			PathAttributes pathAttributes1 = new PathAttributes();
			pathAttributes1.setPointColor(color);
			pathAttributes1.setPathColor(color);
			PathOnChart path1 = new PathOnChart(points, pathAttributes1);

			LineChartPathCollection paths = new LineChartPathCollection();
			paths.addPath(path1);
			
			LineChartAttributes lineChartAttributes = new LineChartAttributes();
			lineChartAttributes.setDisplayHeight(900 * LineChartConstant.CHART_HEIGHT_PERCENT);
			lineChartAttributes.setDisplayWidth(800 * LineChartConstant.CHART_WIDTH_PERCENT);
			lineChartAttributes.initLineChartBodyDefaultAttribute();
			LineChartView view = new LineChartView(activity, paths, lineChartAttributes, revenue);
			return view;
		}
	}
	
	public void deleteLine(ArrayList<ProductRevenue> revenue)
	{
		if( !productRevenues.contains(revenue))
			return;
		productRevenues.remove(revenue);
		PathOnChart pathOnChart = mRevenuePathMap.get(revenue);
		mRevenuePathMap.remove(revenue);
		deleteLineInternal(pathOnChart);
	}
	
	private void deleteLineInternal(PathOnChart path)
	{
		mMonthlyPaths.removePath(path);
		configurePath(mMonthlyPaths);
		mOriginalY = mNO_of_y_positive_unit * mY_unit_length + mYtl;
		mOriginalX = mXtl;
		LineChartDataUtil.calculateOtherPaths(this);
		configureCurrentPath();
		updateRedrawList(path);
		updateRedrawListDuetoPotentialYAxisChange();
		this.invalidate();
	}
	
	private void updateRedrawList(PathOnChart path)
	{
		if( mPointsTobeRedraw.isEmpty())
			return;
		int size = path.getPoints().size();
		for( int i = 0; i < size; i++)
		{
			mPointsTobeRedraw.remove(path.getPoints().get(i));
		}
		int reDrawNumber = mPointsTobeRedraw.size();
		LineChartPathCollection currentpath = getCurrentPath();
		ArrayList<PointOnChart> deleteList = new ArrayList<PointOnChart>();
		for( int j = 0; j < reDrawNumber; j++)
		{
			PointOnChart currentPoint = mPointsTobeRedraw.get(j);
			if( !currentPoint.isPointOnPath(currentpath))
				deleteList.add(currentPoint);
		}
		int deleteNumber = deleteList.size();
		for( int k = 0; k < deleteNumber; k++)
			mPointsTobeRedraw.remove(deleteList.get(k));
	}
	
	private void updateRedrawListDuetoPotentialYAxisChange()
	{
		if( mPointsTobeRedraw.isEmpty())
			return;
		int size = mPointsTobeRedraw.size();
		for (int m = 0; m < size; m++)
		{
			PointOnChart pointOnChart = mPointsTobeRedraw.get(m);
			float y =  mY_translate_factor - ((float) (pointOnChart.getOriginalY()) * mY_unit_length);
			pointOnChart.setConvertedY(y);
		}
	}
	
	private void updateRedrawListDuetoPotentialXAxisChange()
	{
		if( mPointsTobeRedraw.isEmpty())
			return;
		int size = mPointsTobeRedraw.size();
		for (int m = 0; m < size; m++)
		{
			PointOnChart pointOnChart = mPointsTobeRedraw.get(m);
			float x = mX_translate_factor + ((float) (pointOnChart.getOriginalX()) * mX_unit_length);
			pointOnChart.setConvertedX(x);
		}
	}
	
	public LineChartAttributes getLineChartAttributes()
	{
		return mLineChartAttributes;
	}
	
	public float getOriginX()
	{
		return mOriginalX;
	}
	
	public float getYTL()
	{
		return mYtl;
	}
	
	public float getYUnitLength()
	{
		return mY_unit_length;
	}
	
	public float getXUnitLength()
	{
		return mX_unit_length;
	}
	
	public float getNumberOfYPositiveUnit()
	{
		return mNO_of_y_positive_unit;
	}
	
	public LineChartPathCollection getMonthlyPath()
	{
		return mMonthlyPaths;
	}
	
	public LineChartPathCollection getQuaterlyPath()
	{
		return mQuaterlyPaths;
	}
	
	public LineChartPathCollection getYearlyPath()
	{
		return mYearlyPaths;
	}
	
	public int getCurrentMode()
	{
		return mCurrentChartMode;
	}
	
	public LineChartPathCollection getCurrentPath()
	{
		switch (mCurrentChartMode) 
		{
			case LineChartConstant.MONTHLY_MODE:
				return mMonthlyPaths;
			case LineChartConstant.QUATERLY_MODE:
				return mQuaterlyPaths;
			case LineChartConstant.YEARLY_MODE:
				return mYearlyPaths;
			default:
				return null;
		}
	}
	
	private void configureCurrentPath()
	{
		switch (mCurrentChartMode) 
		{
			case LineChartConstant.QUATERLY_MODE:
				configurePath(mQuaterlyPaths);
				break;
			case LineChartConstant.YEARLY_MODE:
				configurePath(mYearlyPaths);
				break;
			default:
				break;
		}
	}
	
	private void configurePath(LineChartPathCollection path)
	{
		ArrayList<PathOnChart> currentPath = path.getPathCollection();
		double minimum_y = 0;
		double maximum_y = 0;
		for (PathOnChart pathOnChart : currentPath) 
		{
			ArrayList<PointOnChart> points = pathOnChart.getPoints();
			for (PointOnChart pointOnChart : points) 
			{
				if (pointOnChart.getOriginalY() < minimum_y)
					minimum_y = pointOnChart.getOriginalY();
				if (pointOnChart.getOriginalY() > maximum_y)
					maximum_y = pointOnChart.getOriginalY();
			}
		}
		mNO_of_y_negetive_unit = (float) Math.abs(minimum_y);
		mNO_of_y_positive_unit = (float) Math.abs(maximum_y);
		mX_unit_length = (float) (mChart_width / mNO_of_x_positive_unit);
		if( mCurrentChartMode == LineChartConstant.YEARLY_MODE && mIsInYearRedrawMode == false)
			mX_unit_length = mX_unit_length * 2;
		mY_unit_length = (float) (mChart_height / (mNO_of_y_negetive_unit + 
				LineChartDataUtil.getMaxYValue(mNO_of_y_positive_unit))); 
																
		mY_translate_factor = mDisplay_height - mOffset_bottom;
		mX_translate_factor = mOffset_left;
		
		mY_translate_factor = mDisplay_height - (mNO_of_y_negetive_unit * mY_unit_length) - mOffset_bottom;
		for (PathOnChart pathOnChart : currentPath) 
		{
			ArrayList<PointOnChart> points = pathOnChart.getPoints();
			for (PointOnChart pointOnChart : points) 
			{
				float x = mX_translate_factor + ((float) (pointOnChart.getOriginalX()) * mX_unit_length);
				pointOnChart.setConvertedX(x);
				float y =  mY_translate_factor - ((float) (pointOnChart.getOriginalY()) * mY_unit_length);
				if( pointOnChart.isDummyPoint())
					y = LineChartConstant.INVALID_Y_COORDINATE;
				pointOnChart.setConvertedY(y);
			}
		}
	}
	
	@Override
	protected void onDraw(Canvas canvas) 
	{
		super.onDraw(canvas);
		drawAxisNames(canvas);
		drawBackground(canvas);
		drawPoints(canvas);
		drawPaths(canvas);
		drawXGrid(canvas);
		drawYGrid(canvas);
		drawXAxis(canvas);
		reDrawClickedPoint(canvas);
	}

	private void drawBackground(Canvas canvas)
	{
		if (mLineChartAttributes.getBackgroundBitmap() != null)
			canvas.drawBitmap(mLineChartAttributes.getBackgroundBitmap(), 0, 0, mLinePaint);
	}
	
	private void drawPaths(Canvas canvas) 
	{
		ArrayList<PathOnChart> currentPath = getCurrentPath().getPathCollection();
		mLinePaint.setStyle(Paint.Style.STROKE);
		for (PathOnChart pathOnChart : currentPath) 
		{
			mLinePaint.setColor(Color.parseColor(pathOnChart.getPathColor()));
			mLinePaint.setStrokeWidth(pathOnChart.getStrokeWidthOfPath());
			Path path = new Path();
			int firstNoDummyIndex = pathOnChart.getFirstNoneDummyPointIndex();
			PointOnChart firstNoDummyPoint = pathOnChart.getPoints().get(firstNoDummyIndex);
			path.moveTo(firstNoDummyPoint.getConvertedX(), firstNoDummyPoint.getConvertedY());
			int totalCount = pathOnChart.getPoints().size();
			firstNoDummyIndex++;
			for (int i = firstNoDummyIndex; i < totalCount; i++) 
			{
				PointOnChart point = pathOnChart.getPoints().get(i);
				if( point.isDummyPoint())
					continue;
				path.quadTo(firstNoDummyPoint.getConvertedX(), firstNoDummyPoint.getConvertedY(), point.getConvertedX(), point.getConvertedY());
				firstNoDummyPoint = point; 
				path.lineTo(firstNoDummyPoint.getConvertedX(), firstNoDummyPoint.getConvertedY());
				canvas.drawPath(path, mLinePaint);
			}
		}
	}
	
	private void drawAXisNamesUnderMonthlyMode(Canvas canvas)
	{
		float offset = (getNewXbyIndex(1) - getNewXbyIndex(0)) / 3;
		int size = mXAxisNameCollection.monthlysize();
		for (int k = 0; k < size; k++) 
		{
			String monthString = mXAxisNameCollection.getMonthSemanticNamebyIndex(k);
			canvas.drawText(monthString, getNewXbyIndex(k) + offset, mOriginalY + LineChartConstant.MONTH_MARGIN_ABOVE_XAXIS, mTooltipPaint);
			if( k % 12 == 0)
				canvas.drawText(mXAxisNameCollection.getYearbyIndex(k), getNewXbyIndex(k) + offset, mOriginalY + LineChartConstant.YEAR_MARGIN_ABOVE_XAXIS, mTooltipPaint);
		}
	}
	
	private void drawAXisNamesUnderQuaterlyMode(Canvas canvas)
	{
		float offset = LineChartConstant.QUATERLY_XAXIS_NAME_OFFSET;
		
		PathOnChart currentPath = getCurrentPath().getCurrentPath(0);
		int size = currentPath.getPoints().size();
		for (int k = 0; k < size; k++) 
		{
			PointOnChart point = currentPath.getPoints().get(k);
			if( point.getQuaterName().equals("Q1"))
				canvas.drawText("" + point.getYear(), point.getConvertedX() + offset, mOriginalY + LineChartConstant.YEAR_MARGIN_ABOVE_XAXIS, mTooltipPaint);
		}
	}
	
	private void drawAXisNamesUnderYearlyMode(Canvas canvas)
	{
		float offset = LineChartConstant.YEARLY_XAXIS_NAME_OFFSET;
		
		PathOnChart currentPath = getCurrentPath().getCurrentPath(0);
		int size = currentPath.getPoints().size();
		for (int k = 0; k < size; k++) 
		{
			PointOnChart point = currentPath.getPoints().get(k);
			canvas.drawText("" + point.getYear(), point.getConvertedX() + offset, mOriginalY + LineChartConstant.YEAR_MARGIN_ABOVE_XAXIS, mTooltipPaint);
		}
	}
	
	private void drawAxisNames(Canvas canvas) 
	{
		mTooltipPaint.setColor(Color.WHITE);
		switch (mCurrentChartMode) 
		{
			case LineChartConstant.MONTHLY_MODE:
				drawAXisNamesUnderMonthlyMode(canvas);
				break;
			case LineChartConstant.QUATERLY_MODE:
				drawAXisNamesUnderQuaterlyMode(canvas);
				break;
			case LineChartConstant.YEARLY_MODE:
				drawAXisNamesUnderYearlyMode(canvas);
				break;
			default:
				break;
		}
	}

	private void setMaxCoordinateX(float pointX)
	{
		if( pointX >= mMaxCoordinateX)
			mMaxCoordinateX = pointX;
	}
	
	private void drawPoints(Canvas canvas) 
	{
		mPointPaint.setStrokeJoin(Paint.Join.ROUND);
		mPointPaint.setStrokeCap(Paint.Cap.ROUND);
		ArrayList<PathOnChart> currentPath = getCurrentPath().getPathCollection();
		for (PathOnChart path : currentPath) 
		{
			int size = path.getPoints().size();
			setMaxCoordinateX(path.getPoints().get(size-1).getConvertedX());
			mPointPaint.setColor(Color.parseColor(path.getPointColor()));
			float r = path.getRadiusOfPoints();
			for (PointOnChart point : path.getPoints()) 
			{
				if( point.isDummyPoint())
					continue;
				float x = point.getConvertedX();
				float y = point.getConvertedY();
				canvas.drawRect(x - r, y - r, x + r, y + r, mPointPaint);
			}
		}
	}

	private void reDrawClickedPoint(Canvas canvas)
	{
		if( mPointsTobeRedraw.isEmpty())
			return;
		switch (mCurrentChartMode) 
		{
			case LineChartConstant.MONTHLY_MODE:
				reDrawOnMonthlyMode(canvas);
				break;
			case LineChartConstant.QUATERLY_MODE:
				reDrawOnQuaterlyMode(canvas);
				break;
			case LineChartConstant.YEARLY_MODE:
				reDrawOnYearlyMode(canvas);
				break;
			default:
				break;
		}
	}
	
	private void reDrawOnQuaterlyMode(Canvas canvas)
	{
		int size = mPointsTobeRedraw.size();
		float r = LineChartConstant.POINT_RADIUS * LineChartConstant.CLICKED_SCALE_RATE;
		for( int i = 0; i < size; i++)
		{
			PointOnChart point = mPointsTobeRedraw.get(i);
			float x = point.getConvertedX();
			float y = point.getConvertedY();
			mTooltipPaint.setColor(Color.parseColor(point.getPointColor()));
			canvas.drawRect(x - r, y - r, x + r, y + r, mTooltipPaint);
			mTooltipHandler.drawToolTip(point, canvas, x, y, r);
		}
	}

	private void reDrawOnYearlyMode(Canvas canvas)
	{
		int size = mPointsTobeRedraw.size();
		float r = LineChartConstant.POINT_RADIUS * LineChartConstant.CLICKED_SCALE_RATE;
		for( int i = 0; i < size; i++)
		{
			PointOnChart point = mPointsTobeRedraw.get(i);
			float x = point.getConvertedX();
			float y = point.getConvertedY();
			mTooltipPaint.setColor(Color.parseColor(point.getPointColor()));
			canvas.drawRect(x - r, y - r, x + r, y + r, mTooltipPaint);
			mTooltipHandler.drawToolTip(point, canvas, x, y, r);
		}
	}
	
	private void reDrawOnMonthlyMode(Canvas canvas)
	{
		int size = mPointsTobeRedraw.size();
		float r = LineChartConstant.POINT_RADIUS * LineChartConstant.CLICKED_SCALE_RATE;
		for( int i = 0; i < size; i++)
		{
			PointOnChart point = mPointsTobeRedraw.get(i);
			float x = point.getConvertedX();
			float y = point.getConvertedY();
			mTooltipPaint.setColor(Color.parseColor(point.getPointColor()));
			canvas.drawRect(x - r, y - r, x + r, y + r, mTooltipPaint);
			mTooltipHandler.drawToolTip(point, canvas, x, y , r);
		}
	}
	
	public void displayToolTip(PointOnChart point)
	{
		if( mPointsTobeRedraw.contains(point))
			mPointsTobeRedraw.remove(point);
		else
			mPointsTobeRedraw.add(point);
		this.invalidate();
	}
	
	private void drawXAxis(Canvas canvas) 
	{
		mLinePaint.setColor(mLineChartAttributes.getXAxisColor());
		mLinePaint.setStrokeWidth(mLineChartAttributes.getXAxisWidth());
		canvas.drawLine(mXtl,mOriginalY, mMaxCoordinateX, mOriginalY, mLinePaint);
	}

	private void drawXGrid(Canvas canvas) 
	{
		mLinePaint.setStrokeWidth(mLineChartAttributes.getXGridWidth());
		mLinePaint.setColor(mLineChartAttributes.getXGridColor());
		for( int i = 0 ; i < LineChartConstant.DEFAULT_XGRID_LINE_NUMBER; i++)
		{
			canvas.drawLine(mXtl, mYtl + (i * mChart_height / LineChartConstant.DEFAULT_XGRID_LINE_NUMBER ), mMaxCoordinateX, 
					mYtr + (i * mChart_height / LineChartConstant.DEFAULT_XGRID_LINE_NUMBER ), mLinePaint);
		}
	}
	
	private void drawYGrid(Canvas canvas) 
	{
		mLinePaint.setStrokeWidth(mLineChartAttributes.getYGridWidth());
		mLinePaint.setColor(mLineChartAttributes.getYGridColor());
		int size = getMaxPointNumber();
		for( int i = 1; i < size; i++)
		{
			float newX = getNewXbyIndex(i);
			drawLinewithOffset(canvas,newX);
			if( mCurrentChartMode == LineChartConstant.YEARLY_MODE )
				drawLinewithOffset(canvas, newX - mX_unit_length / 2);
		}
	}
	
	private int getMaxPointNumber()
	{
		ArrayList<PathOnChart> path = getCurrentPath().getPathCollection();
		ArrayList<Integer> temp = new ArrayList<Integer>();
		for( int i = 0; i < path.size(); i++)
			temp.add(path.get(i).getPoints().size());
		Collections.sort(temp);
		return temp.get(temp.size()-1);
	}
	
	private float getNewXbyIndex(int index)
	{
		PathOnChart currentPath = getCurrentPath().getCurrentPath(0);
		return currentPath.getPoints().get(index).getConvertedX();
	}
	
	private void drawLinewithOffset(Canvas canvas, float newX)
	{
		canvas.drawLine(newX, mDisplay_height - mOffset_bottom, newX, mOffset_top, mLinePaint);
	}
	
	public int getFirstVisibleLocation()
	{
		LineChartPathCollection currentPathCollection = getCurrentPath();
		return currentPathCollection.getFirstVisibleLocation();
	}

}